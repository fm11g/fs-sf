---
name: tpf-status
description: 오늘의 정책자금 숏폼 공장의 현황을 확인한다. "현황판", "지금 뭐 기다려?", "어디까지 됐어", "검수 대기", "작업 효율" 같은 요청에 사용.
---

# 현황 확인

1. `tpf board` (MCP: `factory_board`) 로 콘텐츠별 단계 상태를 가져온다.
2. 다음 순서로 짧게 보고한다.
   - **결정이 필요한 것**: `current_step` 의 상태가 `review` 인 콘텐츠 — 주제, 단계, 한 줄 요약
   - **재작업 필요/실패**: `stale` `rejected` `failed`
   - **진행 중**: `running`
   - 나머지는 개수만
3. 운영자가 특정 콘텐츠를 물으면 `tpf get <id>` 로 단계별 상태·규칙 검사·AI 의견 요약을, `tpf get <id> <step>` 으로 산출물 전문을 본다.
4. 효율을 물으면 `tpf metrics --days 30`: 가장 오래 걸리는 단계, 재작업이 많은 단계, AI 결정 비율, 조회→신청 전환을 먼저 말한다.
5. 채널 반응을 물으면 `tpf channels`, 편성은 `tpf lineup` (`tpf-editorial`).
6. 점수를 물으면 `tpf learn` (단계별 평가 수·평균), 데이터 저장 상태는 `tpf export status` (GitHub·시트 대기·실패).
7. 서버 AI가 안 돌면 `tpf providers` 로 어떤 제공자가 준비됐는지 확인한다.

표로 길게 나열하지 말고, 운영자가 지금 해야 할 일 위주로 말한다.

{{COMMON}}
