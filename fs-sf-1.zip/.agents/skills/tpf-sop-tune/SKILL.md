---
name: tpf-sop-tune
description: 단계별 SOP(md)·자유도·결정 방식·AI 제공자를 조정한다. "SOP 고쳐줘", "기획 단계는 숫자 훅 우선으로", "이 단계는 AI가 결정하게", "반려가 자주 나는 이유 반영", 성과를 지침에 반영할 때 사용.
---

# SOP 조정

> 점수 기반 보완·전체 재정리는 `tpf-learn` 스킬입니다. 손으로 고치기 전에도 `tpf notes <step>` 으로 지금까지의 학습을 먼저 읽습니다. 이 스킬은 운영자가 직접 지시하거나, 지표·반려 사유를 근거로 손으로 고칠 때 씁니다. 대기 중인 학습 제안이 있으면(`tpf proposals <step> --status pending`) 먼저 그것을 처리할지 묻습니다.

1. 현재 값 확인: `tpf sop list` (자유도·결정 방식·제공자), `tpf sop get <step>` (md 전문).
2. 근거 확인 (추측으로 고치지 않는다)
   - `tpf metrics` — 재작업이 많은 단계(`avg_attempts`), 대기가 긴 단계, 콘텐츠별 조회·신청
   - 필요하면 최근 콘텐츠의 `tpf get <id> <step>` 에서 반려 사유(`decision_note`)·AI 검수 지적
3. 수정 원칙
   - md 구조 유지: `목적 / 집중 포인트 / 체크리스트 / 금지 / 사람이 결정할 것`
   - 새 지침은 `집중 포인트` **맨 위**에 날짜와 근거를 붙여 한 줄. 예) `- (11/20) 마감 훅이 질문형보다 신청 전환 2배 → 마감 있는 공고는 마감 훅 우선`
   - 검수에서 반복 지적되는 것은 `체크리스트` 에 항목으로
   - 한 줄 = 한 지시. 길어지면 오래된 줄을 합치거나 지운다 (md가 길수록 느리고 흐려진다)
   - JSON 형식·글자수 상한 같은 기계 규칙은 md에 쓰지 않는다 (코드에 고정되어 있음)
   - 사실 정확성·금지 표현을 느슨하게 만드는 지침은 넣지 않는다
4. 적용 전 **변경 전/후를 운영자에게 보여주고 확인**받는다.
5. 적용: 고친 md를 파일로 저장 → `tpf sop set <step> --file <파일> --note "변경 이유"`. 설정만 바꿀 때: `tpf sop set <step> --freedom 2 --gate ai --provider auto`.
   - 자유도: 사실 단계(조사·이벤트) 0~1, 표현 단계 2, 실험 3
   - 결정 방식: 1회 통과율이 2주간 90% 이상이면 `ai` 후보. 조사·렌더·업로드는 `manual` 유지 권장
6. 저장소의 `sop/NN-step.md` 도 같은 내용으로 맞춘다(이 저장소 안에서 작업 중이면 파일을 직접 수정해 커밋).

## 공장 조작 방법 (모든 스킬 공통)

두 가지 중 되는 것을 씁니다. 도구 이름과 인자는 같습니다.

1. **MCP 도구** — `tpf` 서버가 연결되어 있으면 `factory_board`, `content_get`, `pipeline_advance`, `step_run`, `step_decide`, `step_brief`, `step_submit`, `sop_get` … 을 직접 호출
2. **CLI** — MCP가 없으면 저장소 루트에서 `node bin/tpf.mjs <명령>` (환경변수 `TPF_URL`, `MCP_TOKEN` 또는 `.env.tpf`). `node bin/tpf.mjs help` 로 전체 명령 확인

단계 키: `research`(조사) `plan`(기획) `script`(40초 대사) `offer`(이벤트) `landing`(랜딩 문구) `design`(디자인) `copy`(채널 카피) `post`(SEO 글) `render`(렌더) `publish`(업로드)
상태: `pending` 대기 · `running` 작업 중 · `review` 검수 대기 · `approved` 승인 · `rejected` 반려 · `stale` 재작업 필요 · `failed` 실패

## 반드시 지킬 것

- `publish`(외부 공개)는 운영자가 이번 대화에서 명시적으로 요청했을 때만 실행합니다.
- 승인(`approve`)은 운영자가 맡겼을 때만 대신 합니다. 맡기지 않았으면 산출물을 요약해 보여주고 결정을 묻습니다.
- 금액·금리·기간·자격은 조사 산출물에 있는 것만 씁니다. 승인·한도 보장 표현, 근거 없는 마감·선착순은 만들지 않습니다.
